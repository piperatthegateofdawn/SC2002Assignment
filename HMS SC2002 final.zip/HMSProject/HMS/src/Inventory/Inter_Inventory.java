package Inventory;

public interface Inter_Inventory extends InventoryCommon, InventoryReplenishment, InventoryManagement, InventoryLowStockAlert{
    
}
