package Inventory;

public interface InventoryLowStockAlert {
    void updateLowStockAlert(String medicineName, int newLowStockAlert);

}
